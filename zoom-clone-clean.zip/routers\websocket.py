from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy import select

from database import SessionLocal
from models import Participant
from services.websocket_manager import manager

router = APIRouter(tags=["WebSocket"])


@router.websocket("/ws/meetings/{meeting_id}")
async def meeting_websocket(websocket: WebSocket, meeting_id: str):
    await manager.connect(meeting_id, websocket)

    participant_id = None

    try:
        while True:
            message = await websocket.receive_json()

            # The first message from the client identifies the participant.
            if message.get("type") == "peer-join":
                participant_id = message.get("participantId")

                await manager.broadcast(
                    meeting_id,
                    {
                        "type": "participant_joined",
                        "meeting_id": meeting_id,
                        "participantId": participant_id,
                    },
                    exclude=websocket,
                )

                continue

            await manager.broadcast(
                meeting_id,
                message,
                exclude=websocket,
            )

    except WebSocketDisconnect:
        manager.disconnect(meeting_id, websocket)

        # Mark this participant as having left.
        if participant_id is not None:
            db = SessionLocal()

            try:
                participant = db.scalar(
                    select(Participant).where(
                        Participant.id == participant_id,
                        Participant.status == "joined",
                    )
                )

                if participant:
                    from datetime import datetime

                    participant.status = "left"
                    participant.left_at = datetime.utcnow()

                    db.commit()

            finally:
                db.close()

        await manager.broadcast(
            meeting_id,
            {
                "type": "participant_left",
                "meeting_id": meeting_id,
                "participantId": participant_id,
            },
        )