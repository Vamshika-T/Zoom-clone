from collections import defaultdict

from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        self.rooms: dict[str, list[WebSocket]] = defaultdict(list)

    async def connect(
        self,
        meeting_id: str,
        websocket: WebSocket,
    ):
        await websocket.accept()

        self.rooms[meeting_id].append(
            websocket
        )

    def disconnect(
        self,
        meeting_id: str,
        websocket: WebSocket,
    ):
        if meeting_id not in self.rooms:
            return

        if websocket in self.rooms[meeting_id]:
            self.rooms[meeting_id].remove(websocket)

        if not self.rooms[meeting_id]:
            del self.rooms[meeting_id]

    async def broadcast(
        self,
        meeting_id: str,
        message: dict,
        exclude: WebSocket | None = None,
    ):
        connections = list(
            self.rooms.get(meeting_id, [])
        )

        for connection in connections:
            if connection is exclude:
                continue

            try:
                await connection.send_json(message)
            except Exception:
                self.disconnect(
                    meeting_id,
                    connection,
                )


manager = ConnectionManager()