"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
    ArrowLeft,
    Copy,
    MoreVertical,
    ShieldCheck,
    Video,
} from "lucide-react";

import {
    getMeeting,
    joinMeeting,
    getParticipants,
    leaveMeeting,
    updateParticipant,
    muteAll,
    removeParticipant,
} from "../lib/api";

import MeetingToolbar from "./MeetingToolbar";
import ParticipantsPanel from "./ParticipantsPanel";
import ChatPanel from "./ChatPanel";

const API_URL =
    process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000";

const WS_URL = API_URL.replace(/^http/, "ws");

const ICE_SERVERS = {
    iceServers: [
        {
            urls: "stun:stun.l.google.com:19302",
        },
    ],
};

export default function MeetingRoom({ meetingId }) {
    const router = useRouter();
    const searchParams = useSearchParams();

    const hostMode = searchParams.get("host") === "true";
    const queryName = searchParams.get("name");

    const localVideoRef = useRef(null);
    const localStreamRef = useRef(null);

    const socketRef = useRef(null);

    const peerConnectionsRef = useRef({});
    const remoteVideoRefs = useRef({});

    const participantRef = useRef(null);
    const joinInProgressRef = useRef(false);

    const [meeting, setMeeting] = useState(null);
    const [currentParticipant, setCurrentParticipant] = useState(null);
    const [participants, setParticipants] = useState([]);

    const [loading, setLoading] = useState(true);
    const [joining, setJoining] = useState(false);
    const [error, setError] = useState("");

    const [audioMuted, setAudioMuted] = useState(false);
    const [videoEnabled, setVideoEnabled] = useState(true);

    const [activePanel, setActivePanel] = useState(null);
    const [messages, setMessages] = useState([]);

    const [remoteStreams, setRemoteStreams] = useState({});
    const [isScreenSharing, setIsScreenSharing] = useState(false);
    const [showMoreMenu, setShowMoreMenu] = useState(false);
    const [copied, setCopied] = useState(false);

    const isHost = hostMode;

    useEffect(() => {
        participantRef.current = currentParticipant;
    }, [currentParticipant]);

    const loadMeeting = useCallback(async () => {
        try {
            setLoading(true);
            setError("");

            const data = await getMeeting(meetingId);
            setMeeting(data);
        } catch (err) {
            setError(err.message || "Meeting not found.");
        } finally {
            setLoading(false);
        }
    }, [meetingId]);

    useEffect(() => {
        loadMeeting();
    }, [loadMeeting]);

    const refreshParticipants = useCallback(async () => {
        try {
            const data = await getParticipants(meetingId);
            setParticipants(data);
        } catch {
            // Ignore temporary polling errors.
        }
    }, [meetingId]);

    const closePeerConnection = useCallback((participantId) => {
        const peer = peerConnectionsRef.current[participantId];

        if (peer) {
            peer.close();
            delete peerConnectionsRef.current[participantId];
        }

        setRemoteStreams((current) => {
            const next = { ...current };
            delete next[participantId];
            return next;
        });
    }, []);

    const createPeerConnection = useCallback(
        (participantId, createOffer = false) => {
            if (peerConnectionsRef.current[participantId]) {
                return peerConnectionsRef.current[participantId];
            }

            const peer = new RTCPeerConnection(ICE_SERVERS);

            peerConnectionsRef.current[participantId] = peer;

            const localStream = localStreamRef.current;

            if (localStream) {
                localStream.getTracks().forEach((track) => {
                    peer.addTrack(track, localStream);
                });
            }

            peer.onicecandidate = (event) => {
                if (!event.candidate || !socketRef.current) {
                    return;
                }

                socketRef.current.send(
                    JSON.stringify({
                        type: "ice-candidate",
                        senderId: participantRef.current?.id,
                        target: participantId,
                        candidate: event.candidate,
                    })
                );
            };

            peer.ontrack = (event) => {
                const stream = event.streams[0];

                if (!stream) {
                    return;
                }

                setRemoteStreams((current) => ({
                    ...current,
                    [participantId]: stream,
                }));
            };

            peer.onconnectionstatechange = () => {
                if (
                    peer.connectionState === "failed" ||
                    peer.connectionState === "closed"
                ) {
                    closePeerConnection(participantId);
                }
            };

            if (createOffer) {
                peer
                    .createOffer()
                    .then((offer) => peer.setLocalDescription(offer))
                    .then(() => {
                        if (!socketRef.current) {
                            return;
                        }

                        socketRef.current.send(
                            JSON.stringify({
                                type: "offer",
                                senderId: participantRef.current?.id,
                                target: participantId,
                                offer: peer.localDescription,
                            })
                        );
                    })
                    .catch((err) => {
                        console.error("Offer creation failed:", err);
                    });
            }

            return peer;
        },
        [closePeerConnection]
    );

    const handleSocketMessage = useCallback(
        async (message) => {
            const current = participantRef.current;

            if (!current) {
                return;
            }

            if (message.type === "participant_joined") {
                await refreshParticipants();
                return;
            }

            if (message.type === "participant_left") {
                if (message.participantId) {
                    closePeerConnection(message.participantId);
                }

                await refreshParticipants();
                return;
            }

            if (message.type === "peer-join") {
                if (message.participantId === current.id) {
                    return;
                }

                createPeerConnection(message.participantId, true);
                return;
            }

            if (message.type === "offer") {
                if (message.target !== current.id) {
                    return;
                }

                const peer = createPeerConnection(
                    message.senderId,
                    false
                );

                try {
                    await peer.setRemoteDescription(
                        new RTCSessionDescription(message.offer)
                    );

                    const answer = await peer.createAnswer();

                    await peer.setLocalDescription(answer);

                    socketRef.current?.send(
                        JSON.stringify({
                            type: "answer",
                            senderId: current.id,
                            target: message.senderId,
                            answer: peer.localDescription,
                        })
                    );
                } catch (err) {
                    console.error("Offer handling failed:", err);
                }

                return;
            }

            if (message.type === "answer") {
                if (message.target !== current.id) {
                    return;
                }

                const peer =
                    peerConnectionsRef.current[message.senderId];

                if (!peer) {
                    return;
                }

                try {
                    await peer.setRemoteDescription(
                        new RTCSessionDescription(message.answer)
                    );
                } catch (err) {
                    console.error("Answer handling failed:", err);
                }

                return;
            }

            if (message.type === "ice-candidate") {
                if (message.target !== current.id) {
                    return;
                }

                const peer =
                    peerConnectionsRef.current[message.senderId];

                if (!peer) {
                    return;
                }

                try {
                    await peer.addIceCandidate(
                        new RTCIceCandidate(message.candidate)
                    );
                } catch (err) {
                    console.error("ICE candidate failed:", err);
                }

                return;
            }

            if (message.type === "chat") {
                setMessages((currentMessages) => [
                    ...currentMessages,
                    {
                        sender: message.sender || "Participant",
                        participantId: message.participantId,
                        message: message.message,
                        timestamp: message.timestamp || Date.now(),
                    },
                ]);

                return;
            }

            if (message.type === "participant-state") {
                await refreshParticipants();
                return;
            }

            if (message.type === "mute-all") {
                if (message.participantId !== current.id) {
                    setAudioMuted(true);

                    localStreamRef.current
                        ?.getAudioTracks()
                        .forEach((track) => {
                            track.enabled = false;
                        });

                    await refreshParticipants();
                }

                return;
            }

            if (message.type === "participant-removed") {
                if (message.participantId === current.id) {
                    try {
                        await leaveMeeting(meetingId, current.id);
                    } catch {
                        // Continue cleanup.
                    }

                    socketRef.current?.close();

                    Object.values(peerConnectionsRef.current).forEach(
                        (peer) => peer.close()
                    );

                    localStreamRef.current
                        ?.getTracks()
                        .forEach((track) => track.stop());

                    sessionStorage.removeItem(
                        `meeting_${meetingId}`
                    );

                    router.push("/");
                } else {
                    closePeerConnection(message.participantId);
                    await refreshParticipants();
                }

                return;
            }
        },
        [
            closePeerConnection,
            createPeerConnection,
            meetingId,
            refreshParticipants,
            router,
        ]
    );

    const connectSocket = useCallback(
        (participant) => {
            if (socketRef.current) {
                socketRef.current.close();
            }

            const socket = new WebSocket(
                `${WS_URL}/ws/meetings/${meetingId}`
            );

            socketRef.current = socket;

            socket.onopen = () => {
                socket.send(
                    JSON.stringify({
                        type: "peer-join",
                        participantId: participant.id,
                        participantName: participant.display_name,
                    })
                );
            };

            socket.onmessage = async (event) => {
                try {
                    const message = JSON.parse(event.data);

                    if (
                        message.type === "participant_joined" ||
                        message.type === "participant_left"
                    ) {
                        await handleSocketMessage(message);
                        return;
                    }

                    if (message.senderId === participant.id) {
                        return;
                    }

                    await handleSocketMessage(message);
                } catch (err) {
                    console.error("WebSocket message error:", err);
                }
            };

            socket.onerror = (event) => {
                console.error("WebSocket error:", event);
            };
        },
        [handleSocketMessage, meetingId]
    );

    const startMedia = useCallback(async () => {
        if (!navigator.mediaDevices?.getUserMedia) {
            throw new Error(
                "Camera and microphone access is not available."
            );
        }

        const stream =
            await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true,
            });

        localStreamRef.current = stream;

        if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
        }

        return stream;
    }, []);

    const cleanupMedia = useCallback(() => {
        if (localStreamRef.current) {
            localStreamRef.current
                .getTracks()
                .forEach((track) => track.stop());

            localStreamRef.current = null;
        }

        if (localVideoRef.current) {
            localVideoRef.current.srcObject = null;
        }
    }, []);

    const closeConnections = useCallback(() => {
        Object.values(peerConnectionsRef.current).forEach(
            (peer) => peer.close()
        );

        peerConnectionsRef.current = {};

        setRemoteStreams({});
    }, []);

    const cleanupAndLeave = useCallback(
        async (callApi = true) => {
            const participant = participantRef.current;

            if (callApi && participant) {
                try {
                    await leaveMeeting(meetingId, participant.id);
                } catch {
                    // Continue cleanup.
                }
            }

            socketRef.current?.close();
            socketRef.current = null;

            closeConnections();
            cleanupMedia();

            sessionStorage.removeItem(`meeting_${meetingId}`);

            router.push("/");
        },
        [
            cleanupMedia,
            closeConnections,
            meetingId,
            router,
        ]
    );

    useEffect(() => {
        if (!meeting) {
            return;
        }

        if (joinInProgressRef.current) {
            return;
        }

        joinInProgressRef.current = true;

        async function join() {
            try {
                setJoining(true);
                setError("");

                let storedParticipant = null;

                try {
                    const stored = sessionStorage.getItem(
                        `meeting_${meetingId}`
                    );

                    if (stored) {
                        storedParticipant = JSON.parse(stored);
                    }
                } catch {
                    storedParticipant = null;
                }

                if (storedParticipant?.id) {
                    setCurrentParticipant(storedParticipant);
                    participantRef.current = storedParticipant;

                    await refreshParticipants();

                    try {
                        await startMedia();
                    } catch (mediaError) {
                        setError(
                            mediaError.message ||
                            "Camera or microphone permission was denied."
                        );
                    }

                    connectSocket(storedParticipant);

                    return;
                }

                const displayName = hostMode
                    ? "Demo User"
                    : queryName?.trim();

                if (!displayName) {
                    router.replace(
                        `/join?meeting=${encodeURIComponent(meetingId)}`
                    );

                    return;
                }

                const response = await joinMeeting(
                    meetingId,
                    displayName
                );

                const participant = response.participant;

                if (hostMode) {
                    participant.role = "host";
                }

                setCurrentParticipant(participant);
                participantRef.current = participant;

                sessionStorage.setItem(
                    `meeting_${meetingId}`,
                    JSON.stringify(participant)
                );

                await refreshParticipants();

                try {
                    await startMedia();
                } catch (mediaError) {
                    setVideoEnabled(false);

                    setError(
                        mediaError.message ||
                        "Camera or microphone permission was denied."
                    );
                }

                connectSocket(participant);
            } catch (err) {
                setError(
                    err.message || "Unable to join this meeting."
                );
            } finally {
                setJoining(false);
                joinInProgressRef.current = false;
            }
        }

        join();
    }, [
        connectSocket,
        hostMode,
        meeting,
        meetingId,
        queryName,
        refreshParticipants,
        router,
        startMedia,
    ]);

    useEffect(() => {
        if (!currentParticipant) {
            return;
        }

        refreshParticipants();

        const interval = setInterval(
            refreshParticipants,
            3000
        );

        return () => clearInterval(interval);
    }, [currentParticipant, refreshParticipants]);

    useEffect(() => {
        return () => {
            socketRef.current?.close();

            Object.values(peerConnectionsRef.current).forEach(
                (peer) => peer.close()
            );

            localStreamRef.current
                ?.getTracks()
                .forEach((track) => track.stop());
        };
    }, []);

    useEffect(() => {
        Object.entries(remoteVideoRefs.current).forEach(
            ([participantId, element]) => {
                if (!element) {
                    return;
                }

                const stream = remoteStreams[participantId];

                if (stream && element.srcObject !== stream) {
                    element.srcObject = stream;
                }
            }
        );
    }, [remoteStreams]);

    async function toggleAudio() {
        const participant = participantRef.current;

        if (!participant) {
            return;
        }

        const nextMuted = !audioMuted;

        setAudioMuted(nextMuted);

        localStreamRef.current
            ?.getAudioTracks()
            .forEach((track) => {
                track.enabled = !nextMuted;
            });

        try {
            const updated = await updateParticipant(
                meetingId,
                participant.id,
                {
                    audio_muted: nextMuted,
                }
            );

            setCurrentParticipant(updated);
            participantRef.current = updated;

            socketRef.current?.send(
                JSON.stringify({
                    type: "participant-state",
                    senderId: participant.id,
                    participantId: participant.id,
                })
            );

            await refreshParticipants();
        } catch {
            // Keep local state responsive.
        }
    }

    async function toggleVideo() {
        const participant = participantRef.current;

        if (!participant) {
            return;
        }

        const nextEnabled = !videoEnabled;

        setVideoEnabled(nextEnabled);

        localStreamRef.current
            ?.getVideoTracks()
            .forEach((track) => {
                track.enabled = nextEnabled;
            });

        try {
            const updated = await updateParticipant(
                meetingId,
                participant.id,
                {
                    video_enabled: nextEnabled,
                }
            );

            setCurrentParticipant(updated);
            participantRef.current = updated;

            socketRef.current?.send(
                JSON.stringify({
                    type: "participant-state",
                    senderId: participant.id,
                    participantId: participant.id,
                })
            );

            await refreshParticipants();
        } catch {
            // Keep local state responsive.
        }
    }

    async function toggleScreenShare() {
        if (isScreenSharing) {
            stopScreenShare();
            return;
        }

        try {
            const screenStream =
                await navigator.mediaDevices.getDisplayMedia({
                    video: true,
                    audio: false,
                });

            const screenTrack =
                screenStream.getVideoTracks()[0];

            Object.values(peerConnectionsRef.current).forEach(
                (peer) => {
                    const sender = peer
                        .getSenders()
                        .find(
                            (item) => item.track?.kind === "video"
                        );

                    if (sender) {
                        sender.replaceTrack(screenTrack);
                    }
                }
            );

            screenTrack.onended = stopScreenShare;

            setIsScreenSharing(true);
        } catch {
            // User cancelled screen sharing.
        }
    }

    function stopScreenShare() {
        const cameraTrack =
            localStreamRef.current?.getVideoTracks()[0];

        Object.values(peerConnectionsRef.current).forEach(
            (peer) => {
                const sender = peer
                    .getSenders()
                    .find(
                        (item) => item.track?.kind === "video"
                    );

                if (sender && cameraTrack) {
                    sender.replaceTrack(cameraTrack);
                }
            }
        );

        setIsScreenSharing(false);
    }

    function sendChat(message) {
        const participant = participantRef.current;

        if (!participant || !socketRef.current) {
            return;
        }

        const chatMessage = {
            type: "chat",
            senderId: participant.id,
            participantId: participant.id,
            sender: participant.display_name,
            message,
            timestamp: Date.now(),
        };

        setMessages((current) => [
            ...current,
            chatMessage,
        ]);

        socketRef.current.send(
            JSON.stringify(chatMessage)
        );
    }

    async function handleMuteAll() {
        if (!isHost) {
            return;
        }

        try {
            await muteAll(meetingId);

            socketRef.current?.send(
                JSON.stringify({
                    type: "mute-all",
                    senderId: participantRef.current?.id,
                    participantId: participantRef.current?.id,
                })
            );

            await refreshParticipants();
        } catch {
            // Ignore API failure.
        }
    }

    async function handleRemoveParticipant(
        participantId
    ) {
        if (!isHost) {
            return;
        }

        try {
            await removeParticipant(
                meetingId,
                participantId
            );

            socketRef.current?.send(
                JSON.stringify({
                    type: "participant-removed",
                    senderId: participantRef.current?.id,
                    participantId,
                })
            );

            closePeerConnection(participantId);

            await refreshParticipants();
        } catch {
            // Ignore API failure.
        }
    }

    async function copyInviteLink() {
        const link =
            meeting?.invite_link ||
            `${window.location.origin}/meeting/${meetingId}`;

        try {
            await navigator.clipboard.writeText(link);

            setCopied(true);

            setTimeout(() => {
                setCopied(false);
            }, 1800);
        } catch {
            // Clipboard unavailable.
        }
    }

    const remoteParticipantEntries =
        participants.filter(
            (participant) =>
                participant.id !== currentParticipant?.id &&
                remoteStreams[participant.id]
        );

    if (loading) {
        return (
            <main className="flex min-h-screen items-center justify-center bg-[#0f1114] text-white">
                <div className="text-center">
                    <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-white/20 border-t-[#2d8cff]" />
                    <p className="text-sm text-white/70">
                        Loading meeting...
                    </p>
                </div>
            </main>
        );
    }

    if (error && !meeting) {
        return (
            <main className="flex min-h-screen items-center justify-center bg-[#f7f9fc] px-6">
                <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white p-8 text-center shadow-sm">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-red-50">
                        <Video className="text-red-500" />
                    </div>

                    <h1 className="text-xl font-semibold text-gray-900">
                        Unable to join meeting
                    </h1>

                    <p className="mt-2 text-sm text-gray-500">
                        {error}
                    </p>

                    <button
                        onClick={() => router.push("/")}
                        className="mt-6 rounded-lg bg-[#2d8cff] px-5 py-3 text-sm font-medium text-white hover:bg-[#1677e8]"
                    >
                        Back to home
                    </button>
                </div>
            </main>
        );
    }

    return (
        <main className="relative h-screen overflow-hidden bg-[#0f1114] text-white">
            <header className="absolute left-0 right-0 top-0 z-30 flex h-16 items-center justify-between border-b border-white/10 bg-[#17181a]/95 px-5 backdrop-blur">
                <div className="flex min-w-0 items-center gap-4">
                    <button
                        onClick={() => cleanupAndLeave(true)}
                        className="rounded-lg p-2 text-white/70 hover:bg-white/10 hover:text-white"
                    >
                        <ArrowLeft size={20} />
                    </button>

                    <div className="min-w-0">
                        <h1 className="truncate text-sm font-semibold">
                            {meeting?.title || "Meeting"}
                        </h1>

                        <div className="flex items-center gap-2 text-xs text-white/50">
                            <span>{meeting?.meeting_id}</span>

                            {isHost && (
                                <>
                                    <span>•</span>
                                    <span className="text-[#6db3ff]">
                                        Host
                                    </span>
                                </>
                            )}
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <button
                        onClick={copyInviteLink}
                        className="flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-white/80 hover:bg-white/10"
                    >
                        <Copy size={15} />
                        {copied ? "Copied" : "Invite"}
                    </button>

                    <div className="relative">
                        <button
                            onClick={() =>
                                setShowMoreMenu((current) => !current)
                            }
                            className="rounded-lg p-2 text-white/70 hover:bg-white/10 hover:text-white"
                        >
                            <MoreVertical size={19} />
                        </button>

                        {showMoreMenu && (
                            <div className="absolute right-0 top-11 w-52 rounded-xl border border-gray-200 bg-white p-1 shadow-xl">
                                <button
                                    onClick={() => {
                                        copyInviteLink();
                                        setShowMoreMenu(false);
                                    }}
                                    className="w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-100"
                                >
                                    Copy invite link
                                </button>

                                <button
                                    onClick={() => {
                                        setActivePanel("participants");
                                        setShowMoreMenu(false);
                                    }}
                                    className="w-full rounded-lg px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-100"
                                >
                                    Manage participants
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </header>

            <section className="absolute inset-0 px-4 pb-[94px] pt-[76px]">
                {error && (
                    <div className="absolute left-1/2 top-20 z-20 -translate-x-1/2 rounded-lg border border-yellow-500/30 bg-yellow-500/10 px-4 py-2 text-xs text-yellow-200">
                        {error}
                    </div>
                )}

                <div
                    className={`grid h-full gap-3 ${remoteParticipantEntries.length === 0
                            ? "grid-cols-1"
                            : remoteParticipantEntries.length === 1
                                ? "grid-cols-2"
                                : "grid-cols-2"
                        }`}
                >
                    <div className="relative min-h-0 overflow-hidden rounded-xl bg-[#202124]">
                        <video
                            ref={localVideoRef}
                            autoPlay
                            muted
                            playsInline
                            className={`h-full w-full object-cover ${videoEnabled ? "" : "hidden"
                                }`}
                        />

                        {!videoEnabled && (
                            <div className="flex h-full items-center justify-center">
                                <div className="flex h-24 w-24 items-center justify-center rounded-full bg-[#2d8cff] text-3xl font-semibold">
                                    {(
                                        currentParticipant?.display_name ||
                                        "D"
                                    )
                                        .charAt(0)
                                        .toUpperCase()}
                                </div>
                            </div>
                        )}

                        <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-md bg-black/60 px-2.5 py-1.5 text-xs">
                            <span>
                                {currentParticipant?.display_name ||
                                    "You"}
                            </span>

                            {isHost && (
                                <span className="rounded bg-[#2d8cff] px-1.5 py-0.5">
                                    Host
                                </span>
                            )}
                        </div>

                        <div className="absolute right-3 top-3 rounded-md bg-black/50 px-2 py-1 text-xs text-white/70">
                            {audioMuted ? "Muted" : "Live"}
                        </div>
                    </div>

                    {remoteParticipantEntries.map(
                        (participant) => (
                            <div
                                key={participant.id}
                                className="relative min-h-0 overflow-hidden rounded-xl bg-[#202124]"
                            >
                                <video
                                    ref={(element) => {
                                        remoteVideoRefs.current[
                                            participant.id
                                        ] = element;
                                    }}
                                    autoPlay
                                    playsInline
                                    className="h-full w-full object-cover"
                                />

                                <div className="absolute bottom-3 left-3 rounded-md bg-black/60 px-2.5 py-1.5 text-xs">
                                    {participant.display_name}
                                </div>

                                <div className="absolute right-3 top-3 flex gap-1">
                                    {!participant.audio_muted && (
                                        <div className="rounded-md bg-black/50 px-2 py-1">
                                            <ShieldCheck size={13} />
                                        </div>
                                    )}
                                </div>
                            </div>
                        )
                    )}
                </div>

                {remoteParticipantEntries.length === 0 && (
                    <div className="pointer-events-none absolute bottom-[105px] left-1/2 -translate-x-1/2 rounded-full bg-black/50 px-4 py-2 text-xs text-white/60">
                        Waiting for others to join...
                    </div>
                )}
            </section>

            {activePanel === "participants" && (
                <ParticipantsPanel
                    participants={participants}
                    currentParticipantId={currentParticipant?.id}
                    isHost={isHost}
                    onClose={() => setActivePanel(null)}
                    onMuteAll={handleMuteAll}
                    onRemove={handleRemoveParticipant}
                />
            )}

            {activePanel === "chat" && (
                <ChatPanel
                    messages={messages}
                    currentParticipant={currentParticipant}
                    onSend={sendChat}
                    onClose={() => setActivePanel(null)}
                />
            )}

            <MeetingToolbar
                audioMuted={audioMuted}
                videoEnabled={videoEnabled}
                onToggleAudio={toggleAudio}
                onToggleVideo={toggleVideo}
                onParticipants={() =>
                    setActivePanel((current) =>
                        current === "participants"
                            ? null
                            : "participants"
                    )
                }
                onChat={() =>
                    setActivePanel((current) =>
                        current === "chat" ? null : "chat"
                    )
                }
                onShare={toggleScreenShare}
                onMore={() =>
                    setShowMoreMenu((current) => !current)
                }
                onLeave={() => cleanupAndLeave(true)}
            />

            {joining && (
                <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70">
                    <div className="text-center">
                        <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-white/20 border-t-[#2d8cff]" />
                        <p className="text-sm text-white">
                            Joining meeting...
                        </p>
                    </div>
                </div>
            )}
        </main>
    );
}